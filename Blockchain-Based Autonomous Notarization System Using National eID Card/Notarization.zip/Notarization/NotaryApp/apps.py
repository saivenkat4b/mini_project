from django.apps import AppConfig


class NotaryappConfig(AppConfig):
    name = 'NotaryApp'
